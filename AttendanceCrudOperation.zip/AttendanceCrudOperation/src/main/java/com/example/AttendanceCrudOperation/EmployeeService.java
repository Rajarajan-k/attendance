package com.example.AttendanceCrudOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;



@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repository;

    public List<Employee> getAllEmployees() {
        return repository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return repository.findById(id).orElse(null);
    }
    
    public Employee getEmployeeByEmail(String email) {
        return repository.findByEmailId(email).orElseThrow(() -> new RuntimeException("Employee not found with Email: " + email));
    }
    public Employee getEmployeeByMobileNumber(String mobileNumber) {
        return repository.findByMobileNumber(mobileNumber)
                .orElseThrow(() -> new RuntimeException("Employee not found with Mobile Number: " + mobileNumber));
    }
    public List<Employee> getEmployeesByDateOfBirth(LocalDate dateOfBirth) {
    	return repository.findByDateOfBirth(dateOfBirth);
    }
    public List<Employee> getEmployeesByFirstName(String firstName) {
        return repository.findByFirstName(firstName);
    }

    public List<Employee> getEmployeesByExperience(int experience) {
        return repository.findByExperience(experience);
    }

    public List<Employee> getEmployeesBySalary(double salary) {
        return repository.findBySalary(salary);
    }

    public List<Employee> getEmployeesByRole(String role) {
        return repository.findByRole(role);
    }

    public List<Employee> getEmployeesByGender(String gender) {
        return repository.findByGender(gender);
    }
    public List<Employee> getEmployeesByDepartment(String department) {
        return repository.findByDepartment(department);
    }

    public List<Employee> getEmployeesByMaritalStatus(String maritalStatus) {
        return repository.findByMaritalStatus(maritalStatus);
    }




    public Employee addEmployee(Employee employee) {
        return repository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Optional<Employee> employeeOptional = repository.findById(id);

        if (employeeOptional.isPresent()) {
            Employee employee = employeeOptional.get();
            employee.setFirstName(employeeDetails.getFirstName());
            employee.setLastName(employeeDetails.getLastName());
            employee.setRole(employeeDetails.getRole());
            employee.setDepartment(employeeDetails.getDepartment());
            employee.setEmailId(employeeDetails.getEmailId());
            employee.setMobileNumber(employeeDetails.getMobileNumber());
            employee.setSalary(employeeDetails.getSalary());
            employee.setExperience(employeeDetails.getExperience());
            employee.setMaritalStatus(employeeDetails.getMaritalStatus());
            employee.setGender(employeeDetails.getGender());
            employee.setDateOfBirth(employeeDetails.getDateOfBirth());
            return repository.save(employee);
        }

        return null;
    }

    public void deleteEmployee(Long id) {
        repository.deleteById(id);
    }
}
