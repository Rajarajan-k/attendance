package com.example.AttendanceCrudOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    @GetMapping
    public List<Employee> getAllEmployees() {
        return service.getAllEmployees();
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        return service.getEmployeeById(id);
    }

    @GetMapping("/email/{email}")
    public Employee getEmployeeByEmail(@PathVariable String email) {
        return service.getEmployeeByEmail(email);
    }
    @GetMapping("/mobile/{mobileNumber}")
    public Employee getEmployeeByMobileNumber(@PathVariable String mobileNumber) {
        return service.getEmployeeByMobileNumber(mobileNumber);
    }

    @GetMapping("/dob/{dateOfBirth}")
    public List<Employee> getEmployeesByDateOfBirth(@PathVariable String dateOfBirth) {
    	LocalDate dob = LocalDate.parse(dateOfBirth); // Convert String to LocalDate
        return service.getEmployeesByDateOfBirth(dob);
    }
    @GetMapping("/firstname/{firstName}")
    public List<Employee> getEmployeesByFirstName(@PathVariable String firstName) {
        return service.getEmployeesByFirstName(firstName);
    }

    @GetMapping("/experience/{experience}")
    public List<Employee> getEmployeesByExperience(@PathVariable int experience) {
        return service.getEmployeesByExperience(experience);
    }

    @GetMapping("/salary/{salary}")
    public List<Employee> getEmployeesBySalary(@PathVariable double salary) {
        return service.getEmployeesBySalary(salary);
    }

    @GetMapping("/role/{role}")
    public List<Employee> getEmployeesByRole(@PathVariable String role) {
        return service.getEmployeesByRole(role);
    }
    @GetMapping("/gender/{gender}")
    public List<Employee> getEmployeesByGender(@PathVariable String gender) {
        return service.getEmployeesByGender(gender);
    }
    @GetMapping("/department/{department}")
    public List<Employee> getEmployeesByDepartment(@PathVariable String department) {
        return service.getEmployeesByDepartment(department);
    }
    @GetMapping("/maritalStatus/{maritalStatus}")
    public List<Employee> getEmployeesByMaritalStatus(@PathVariable String maritalStatus) {
        return service.getEmployeesByMaritalStatus(maritalStatus);
    }



    @PostMapping
    public Employee addEmployee(@RequestBody Employee employee) {
        return service.addEmployee(employee);
    }

    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        return service.updateEmployee(id, employee);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        service.deleteEmployee(id);
    }
}
