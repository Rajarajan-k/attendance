package com.example.AttendanceCrudOperation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceCrudOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceCrudOperationApplication.class, args);
	}

}
