package com.example.AttendanceCrudOperation;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "employees")
@Data
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private String role;
    private String department;
    private String emailId;
    private String mobileNumber;
    private Double salary;
    private Integer experience;
    private String maritalStatus;
    private String gender;
    private LocalDate dateOfBirth;

    // Getters and Setters (Use Lombok @Getter and @Setter if included)
}

