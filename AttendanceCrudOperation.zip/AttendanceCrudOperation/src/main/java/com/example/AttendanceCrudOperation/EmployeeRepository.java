package com.example.AttendanceCrudOperation;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Search by multiple parameters (any combination)
    @Query("SELECT e FROM Employee e WHERE " +
           "(:email IS NULL OR e.emailId = :email) AND " +
           "(:mobileNumber IS NULL OR e.mobileNumber = :mobileNumber) AND " +
           "(:role IS NULL OR e.role = :role) AND " +
           "(:department IS NULL OR e.department = :department) AND " +
           "(:firstName IS NULL OR e.firstName = :firstName) AND " +
           "(:lastName IS NULL OR e.lastName = :lastName) AND " +
           "(:experience IS NULL OR e.experience = :experience) AND " +
           "(:salary IS NULL OR e.salary = :salary) AND " +
           "(:dateOfBirth IS NULL OR e.dateOfBirth = :dateOfBirth)")
    List<Employee> findByCriteria(
            @Param("email") String email,
            @Param("mobileNumber") String mobileNumber,
            @Param("role") String role,
            @Param("department") String department,
            @Param("firstName") String firstName,
            @Param("lastName") String lastName,
            @Param("experience") Integer experience,
            @Param("salary") Double salary,
            @Param("dateOfBirth") String dateOfBirth
    );
    Optional<Employee> findByEmailId(String email);
    Optional<Employee> findByMobileNumber(String mobileNumber);
    List<Employee> findByDateOfBirth(LocalDate dateOfBirth);
    List<Employee> findByFirstName(String firstName);
    List<Employee> findByExperience(int experience);
    List<Employee> findBySalary(double salary);
    List<Employee> findByRole(String role);
    List<Employee> findByGender(String gender);
    List<Employee> findByDepartment(String department);
    List<Employee> findByMaritalStatus(String maritalStatus);

}
