package com.example.AttendanceCrudOperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceCrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
